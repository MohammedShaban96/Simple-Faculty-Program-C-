#include "StdAfx.h"
#include"course.h"