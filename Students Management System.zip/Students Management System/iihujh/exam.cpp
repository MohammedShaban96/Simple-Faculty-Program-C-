#include "StdAfx.h"
#include "exam.h"

