#include "StdAfx.h"
#include "exams1.h"

