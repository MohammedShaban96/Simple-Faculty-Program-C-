#include "StdAfx.h"
#include "exams2.h"

