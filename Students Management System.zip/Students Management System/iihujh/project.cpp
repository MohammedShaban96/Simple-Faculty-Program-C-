// iihujh.cpp : main project file.

#include "stdafx.h"
#include "Form1.h"

using namespace iihujh;
using namespace System;
using namespace System::Windows::Forms;

[STAThreadAttribute]

int main(array<String^>^args)
{
	// Enabling Windows XP visual effects before any controls are created
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 
	iihujh::Form1 form;
	// Create the main window and run it
	Application::Run(%form);
	return 0;
}